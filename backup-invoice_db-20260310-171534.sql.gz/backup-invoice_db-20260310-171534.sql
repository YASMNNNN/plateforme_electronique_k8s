--
-- PostgreSQL database dump
--

\restrict 6rmD4I5f5XmkDr41ofyv7D3VM5gHkG2wMcOXgCZAAh87WS0hEypv0CmpARSaHux

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: plateforme_user
--

CREATE TABLE public.invoice_items (
    id uuid NOT NULL,
    description character varying(500) NOT NULL,
    line_total_ht numeric(15,4),
    quantity numeric(10,3) NOT NULL,
    tax_rate numeric(5,2),
    unit_price numeric(15,4) NOT NULL,
    invoice_id uuid NOT NULL
);


ALTER TABLE public.invoice_items OWNER TO plateforme_user;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: plateforme_user
--

CREATE TABLE public.invoices (
    id uuid NOT NULL,
    billing_address character varying(500),
    client_email character varying(255),
    client_name character varying(255),
    created_at timestamp(6) without time zone NOT NULL,
    due_date date,
    invoice_number character varying(30),
    issue_date date,
    owner_user_id uuid NOT NULL,
    signature_hash character varying(255),
    status character varying(20) NOT NULL,
    subtotal_ht numeric(15,4),
    total_ttc numeric(15,4),
    updated_at timestamp(6) without time zone,
    vat_amount numeric(15,4),
    vat_rate numeric(5,2),
    CONSTRAINT invoices_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'VALIDATED'::character varying, 'SENT'::character varying, 'PAID'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.invoices OWNER TO plateforme_user;

--
-- Name: products; Type: TABLE; Schema: public; Owner: plateforme_user
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    active boolean NOT NULL,
    category character varying(50) NOT NULL,
    currency character varying(10),
    description character varying(1000),
    name character varying(200) NOT NULL,
    sku character varying(50) NOT NULL,
    tax_rate numeric(7,2),
    tenant_id bigint NOT NULL,
    unit character varying(10),
    unit_price numeric(15,4) NOT NULL
);


ALTER TABLE public.products OWNER TO plateforme_user;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: plateforme_user
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO plateforme_user;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: plateforme_user
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: plateforme_user
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: plateforme_user
--

COPY public.invoice_items (id, description, line_total_ht, quantity, tax_rate, unit_price, invoice_id) FROM stdin;
11111111-1111-1111-1111-111111111201	Audit et conseil	60.0000	1.000	19.00	60.0000	11111111-1111-1111-1111-111111111101
11111111-1111-1111-1111-111111111202	Integration plateforme	40.0000	1.000	19.00	40.0000	11111111-1111-1111-1111-111111111101
11111111-1111-1111-1111-111111111203	Abonnement annuel	250.0000	1.000	19.00	250.0000	11111111-1111-1111-1111-111111111102
d4830867-a2eb-4b5f-9181-1268874ee31a	télée	6000.0000	2000.000	20.00	3.0000	2bb77af4-61a1-4f1b-883c-90e964fd45eb
3800fbc0-41a4-43c6-9e73-a23dea9b7637	Application Mobile iOS et Android	15000.0000	1.000	19.00	15000.0000	11111111-1111-1111-1111-111111111111
5c85c84c-5109-4ee6-ba2e-787e5a228ddd	Développement Site Web E-commerce	5000.0000	1.000	19.00	5000.0000	22222222-2222-2222-2222-222222222222
1d164168-6d1d-43aa-9efc-3408b2968d5f	Application Mobile	15000.0000	1.000	19.00	15000.0000	22222222-2222-2222-2222-222222222222
80a36ed9-4415-409b-abab-cb0c083fe24e	Formation utilisateurs (3 jours)	4500.0000	3.000	19.00	1500.0000	22222222-2222-2222-2222-222222222222
799e70ef-5948-4da9-8192-f2b05a7a7b82	Hébergement 1 an offert	600.0000	0.500	19.00	1200.0000	22222222-2222-2222-2222-222222222222
a3053c1b-ceb1-42d6-aa8a-d59f9a2f6deb	Développement Site Web	5000.0000	1.000	19.00	5000.0000	33333333-3333-3333-3333-333333333333
c5a2d036-28da-43ae-8d96-aee0f3eb250c	SEO & Marketing (1 mois)	4000.0000	1.000	19.00	4000.0000	33333333-3333-3333-3333-333333333333
d0c6fbc0-a2c8-46a8-9be3-9708da2bb6c2	Hébergement Annuel	1000.0000	1.000	19.00	1200.0000	33333333-3333-3333-3333-333333333333
54f5d2fc-d9b0-4571-8324-8058092bd618	Audit Sécurité	3500.0000	1.000	19.00	3500.0000	44444444-4444-4444-4444-444444444444
ef5512c9-be82-419f-b0f4-5293182aef00	Consulting (2 jours)	4000.0000	2.000	19.00	2000.0000	44444444-4444-4444-4444-444444444444
a947881e-6b3d-492c-bd67-186f71c14e66	Développement Application Web	12000.0000	1.000	19.00	12000.0000	240bff2b-e6eb-4ad7-abc8-8096a50c2a68
fb21755e-23a7-4e3a-8d9c-cc9aa99ee9d0	Hébergement 1 an	1200.0000	1.000	19.00	1200.0000	240bff2b-e6eb-4ad7-abc8-8096a50c2a68
a4280c21-a6fd-46f5-abc5-15a991062b51	Formation utilisateurs	6800.0000	4.000	19.00	1700.0000	240bff2b-e6eb-4ad7-abc8-8096a50c2a68
b8841349-96ff-419e-a524-4b4bd2a50230	lk;dekl	30000.0000	2.000	19.00	15000.0000	65701ea7-ac36-43a6-8a05-e093f6f96dd4
a6dff19d-c5f6-4b24-97f7-eda4ff85f816	kqs,do	450000.0000	3.000	19.00	150000.0000	4a3186e7-a113-42d4-a47f-9afe6de5f127
413dc113-cde9-4df0-b4cd-d28e30bce91d	frfenqklen	200000.0000	1.000	19.00	200000.0000	1523884d-05a4-42d2-abb0-0e57917b28c8
82d4c24f-9036-4aa9-bb35-530b9515f86b	développemnt_app	48000.0000	1.000	19.00	48000.0000	fba1c93e-ad3f-4bb2-a48e-2444113a5607
d2dae0eb-0df2-4b5a-b606-138cf497b95e	T G	100000.0000	10.000	20.00	10000.0000	90e1448d-9965-4129-9f50-f5d1fdb83a31
aaaaaaaa-aaaa-aaaa-aaaa-bbbbbbbb0001	Creation site vitrine	2500.0000	1.000	19.00	2500.0000	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa001
aaaaaaaa-aaaa-aaaa-aaaa-bbbbbbbb0002	Maintenance mensuelle	1000.0000	2.000	19.00	500.0000	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa001
aaaaaaaa-aaaa-aaaa-aaaa-bbbbbbbb0003	Design logo et charte graphique	800.0000	1.000	19.00	800.0000	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa002
aaaaaaaa-aaaa-aaaa-aaaa-bbbbbbbb0004	Cartes de visite (500 pcs)	200.0000	1.000	19.00	200.0000	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa002
aaaaaaaa-aaaa-aaaa-aaaa-bbbbbbbb0005	Flyers promotionnels (1000 pcs)	800.0000	1.000	19.00	800.0000	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa002
aaaaaaaa-aaaa-aaaa-aaaa-bbbbbbbb0006	Developpement application de suivi	4000.0000	1.000	19.00	4000.0000	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa003
aaaaaaaa-aaaa-aaaa-aaaa-bbbbbbbb0007	Formation equipe (2 jours)	1200.0000	2.000	19.00	600.0000	aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa003
7e2e6d3e-eed4-4843-9042-685e5f0ffbea	koskdjq	58000.0000	1.000	20.00	58000.0000	cfea594c-119c-4d26-993b-973210d31fde
df8f7a3a-9b29-4ab9-b2ae-9c78a7ce617f	edaef	2000.0000	1.000	20.00	2000.0000	a89e01bc-82e2-4c54-8ef0-0e2285ce0cb5
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: plateforme_user
--

COPY public.invoices (id, billing_address, client_email, client_name, created_at, due_date, invoice_number, issue_date, owner_user_id, signature_hash, status, subtotal_ht, total_ttc, updated_at, vat_amount, vat_rate) FROM stdin;
11111111-1111-1111-1111-111111111101	Tunis, TN	contact@atlas.tn	Societe Atlas	2026-01-10 09:00:00	2026-01-20	INV-2026-0001	2026-01-10	11111111-1111-1111-1111-111111111111	\N	SENT	100.0000	119.0000	2026-01-10 09:00:00	19.0000	19.00
11111111-1111-1111-1111-111111111102	Sfax, TN	finance@delta.tn	Delta Services	2026-01-05 10:30:00	2026-01-15	INV-2026-0002	2026-01-05	11111111-1111-1111-1111-111111111111	\N	PAID	250.0000	297.5000	2026-01-08 16:20:00	47.5000	19.00
11111111-1111-1111-1111-111111111111	15 Avenue Bourguiba, Tunis	contact@techsolutions.tn	Tech Solutions SARL	2026-02-02 09:03:31.777201	2026-02-10	FAC-2026-001	2026-01-10	c30182ab-cc6a-4af0-8be4-db2f6e8b5ebb	\N	PAID	15000.0000	17850.0000	\N	2850.0000	19.00
22222222-2222-2222-2222-222222222222	Tunis, Projet GitOps PFE 2026	yassmine@gitops.tn	Yassmine Test SARL	2026-02-02 09:09:54.561573	2026-02-27	FAC-YASSMINE-2026	2026-01-27	eec5568e-81f0-4066-968e-96a10785e414	\N	VALIDATED	25000.0000	29750.0000	\N	4750.0000	19.00
33333333-3333-3333-3333-333333333333	Lac 1, Tunis	info@digitalagency.tn	Digital Agency Pro	2026-02-02 09:10:33.504225	2026-02-15	FAC-2026-003	2026-01-15	f810ba0d-6c5e-4a19-b18e-c061ff61fcaa	\N	SENT	10000.0000	11900.0000	\N	1900.0000	19.00
44444444-4444-4444-4444-444444444444	Sousse Centre	contact@consulting.tn	Consulting Pro	2026-02-02 09:11:04.066933	2026-02-20	FAC-2026-004	2026-01-20	fefb146c-f3e7-4d7c-9591-8f74e850947c	\N	DRAFT	7000.0000	8330.0000	\N	1330.0000	19.00
240bff2b-e6eb-4ad7-abc8-8096a50c2a68	Tunis, Tunisie	client@paye.tn	Client Payé SARL	2026-02-05 08:55:38.468499	2026-02-20	FAC-PAID-2026	2026-01-20	904b4aec-483b-46f9-9ec0-2c45d19d43c6	\N	PAID	20000.0000	23800.0000	\N	3800.0000	19.00
65701ea7-ac36-43a6-8a05-e093f6f96dd4	Tunis	client0606@gmail.com	CL06	2026-02-05 16:42:27.758113	2026-01-02	\N	2026-01-02	11111111-1111-1111-1111-111111111111	\N	DRAFT	30000.0000	35700.0000	\N	5700.0000	19.00
4a3186e7-a113-42d4-a47f-9afe6de5f127	Monastir	societe77@STRT.com	SOCIETE77	2026-02-07 10:02:55.829011	2026-07-02	\N	2026-07-01	11111111-1111-1111-1111-111111111111	\N	DRAFT	450000.0000	535500.0000	\N	85500.0000	19.00
1523884d-05a4-42d2-abb0-0e57917b28c8	Mahdia	Mohamed354@STR.com	Mohamed	2026-02-07 18:49:32.511764	2026-03-09	FAC-2026-100	2026-02-07	0b7a48f8-9bba-4b74-8cb8-5bfe249aef9d	\N	PAID	200000.0000	238000.0000	\N	38000.0000	19.00
fba1c93e-ad3f-4bb2-a48e-2444113a5607	Sousse	Ahmed4568@SOC.com	Ahmed	2026-02-11 11:48:58.746867	2026-03-13	FAC-2026-102	2026-02-11	08379016-2c63-40b0-a1a4-88ce0422dbe2	\N	PAID	48000.0000	57120.0000	\N	9120.0000	19.00
2bb77af4-61a1-4f1b-883c-90e964fd45eb	Sousse	yasminegr432@gmail.com	yassminegrassa	2026-01-27 11:20:36.054289	2026-04-02	FAC-2026-00015	2025-04-12	11111111-1111-1111-1111-111111111111	\N	VALIDATED	6000.0000	7140.0000	2026-02-13 09:54:02.222744	1140.0000	19.00
90e1448d-9965-4129-9f50-f5d1fdb83a31	EFG	eeeee@gmil.com	G;PĜ;'^	2026-02-15 22:43:00.975293	2026-12-05	FAC-2026-00015	2025-12-05	11111111-1111-1111-1111-111111111111	\N	CANCELLED	100000.0000	119000.0000	2026-02-15 22:43:18.656476	19000.0000	19.00
aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa001	25 Rue de la Liberte, Tunis	comptabilite@cafecentral.tn	Cafe Central SARL	2026-01-08 08:30:00	2026-02-08	FAC-2026-00010	2026-01-08	22222222-2222-2222-2222-222222222222	\N	PAID	3500.0000	4165.0000	2026-01-25 14:00:00	665.0000	19.00
aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa002	12 Souk El Attarine, Tunis	info@boutiquemedina.tn	Boutique Medina	2026-02-01 10:15:00	2026-03-01	FAC-2026-00011	2026-02-01	22222222-2222-2222-2222-222222222222	\N	SENT	1800.0000	2142.0000	2026-02-01 10:15:00	342.0000	19.00
aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaa003	Zone Industrielle, Sousse	facturation@transexpress.tn	Transport Express	2026-02-15 09:00:00	2026-03-15	\N	2026-02-15	22222222-2222-2222-2222-222222222222	\N	DRAFT	5200.0000	6188.0000	\N	988.0000	19.00
cfea594c-119c-4d26-993b-973210d31fde	sienfiuzenuz	houda123@gmail.com	houda	2026-03-01 00:15:29.045165	2026-01-03	FAC-2026-00018	2026-01-02	38cf75eb-1ae9-474e-9b4d-2ce0465820b1	\N	PAID	58000.0000	69020.0000	2026-03-01 00:52:54.634567	11020.0000	19.00
a89e01bc-82e2-4c54-8ef0-0e2285ce0cb5	kdeoj	fzr@fzgfr.com	ijofso	2026-03-01 14:54:46.165464	2025-05-05	FAC-2026-00019	2025-04-02	38cf75eb-1ae9-474e-9b4d-2ce0465820b1	\N	PAID	2000.0000	2380.0000	2026-03-01 14:55:53.713952	380.0000	19.00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: plateforme_user
--

COPY public.products (id, active, category, currency, description, name, sku, tax_rate, tenant_id, unit, unit_price) FROM stdin;
1	t	SERVICES	TND	Création site web responsive avec SEO	Développement Site Web	DEV-WEB-001	19.00	1	projet	5000.0000
2	t	SERVICES	TND	Développement application iOS et Android	Application Mobile	DEV-APP-001	19.00	1	projet	15000.0000
3	t	SERVICES	TND	Support technique et maintenance	Maintenance Mensuelle	MAINT-001	19.00	1	mois	800.0000
4	t	SERVICES	TND	Hébergement serveur VPS	Hébergement Annuel	HOST-001	19.00	1	an	1200.0000
5	t	FORMATION	TND	Formation utilisateurs - 1 journée	Formation	FORM-001	19.00	1	jour	1500.0000
6	t	SERVICES	TND	Audit de sécurité informatique complet	Audit Sécurité	AUDIT-SEC-001	19.00	1	audit	3500.0000
7	t	CONSULTING	TND	Conseil stratégie digitale	Consulting	CONS-001	19.00	1	jour	2000.0000
8	t	MARKETING	TND	Campagne SEO et marketing digital	SEO & Marketing	MARKET-001	19.00	1	mois	4000.0000
\.


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: plateforme_user
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: products idx_product_sku; Type: CONSTRAINT; Schema: public; Owner: plateforme_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT idx_product_sku UNIQUE (sku);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: plateforme_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: plateforme_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: plateforme_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products uk_fhmd06dsmj6k0n90swsh8ie9g; Type: CONSTRAINT; Schema: public; Owner: plateforme_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT uk_fhmd06dsmj6k0n90swsh8ie9g UNIQUE (sku);


--
-- Name: idx_invoice_item_invoice; Type: INDEX; Schema: public; Owner: plateforme_user
--

CREATE INDEX idx_invoice_item_invoice ON public.invoice_items USING btree (invoice_id);


--
-- Name: idx_invoice_number; Type: INDEX; Schema: public; Owner: plateforme_user
--

CREATE INDEX idx_invoice_number ON public.invoices USING btree (invoice_number);


--
-- Name: idx_invoice_owner; Type: INDEX; Schema: public; Owner: plateforme_user
--

CREATE INDEX idx_invoice_owner ON public.invoices USING btree (owner_user_id);


--
-- Name: idx_invoice_status; Type: INDEX; Schema: public; Owner: plateforme_user
--

CREATE INDEX idx_invoice_status ON public.invoices USING btree (status);


--
-- Name: idx_product_category; Type: INDEX; Schema: public; Owner: plateforme_user
--

CREATE INDEX idx_product_category ON public.products USING btree (category);


--
-- Name: idx_product_name; Type: INDEX; Schema: public; Owner: plateforme_user
--

CREATE INDEX idx_product_name ON public.products USING btree (name);


--
-- Name: idx_product_tenant; Type: INDEX; Schema: public; Owner: plateforme_user
--

CREATE INDEX idx_product_tenant ON public.products USING btree (tenant_id);


--
-- Name: invoice_items fk46ae0lhu1oqs7cv91fn6y9n7w; Type: FK CONSTRAINT; Schema: public; Owner: plateforme_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT fk46ae0lhu1oqs7cv91fn6y9n7w FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 6rmD4I5f5XmkDr41ofyv7D3VM5gHkG2wMcOXgCZAAh87WS0hEypv0CmpARSaHux

